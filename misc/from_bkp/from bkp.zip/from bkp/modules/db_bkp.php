<?php

/*
 * C:/xampp/php/php.exe -f C:/xampp/htdocs/armyrisdev/modules/db_bkp.php
 * C:/wamp/bin/php/php5.5.12/php.exe -f C:/wamp/www/armyrisdev/modules/db_bkp.php
 */

require('C:/xampp/htdocs/armyris/core/init_alt.php');
$db = connectDb(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

$username = DB_USERNAME;
$dbname = DB_DATABASE;


$filename = BASE_DIRECTORY.'/DB/'.date('Y').'/'.date('m')."/{$dbname}_".date('Ymd_His').".sql";
//die($filename);
confirmDirExists($filename);
$command = "mysqldump -u $username $dbname > $filename";
exec($command);
