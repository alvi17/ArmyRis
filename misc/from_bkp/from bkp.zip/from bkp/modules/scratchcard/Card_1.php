<?php

/**
 * Description of Scratchcard
 * 
 * @author Md. Rafiqul Islam <rafiq.kuet@gmail.com>
 * @date January 12, 2017 03:16 am
 */

class Card {
    public function __construct() {}
    
    public function listCards($code, $is_total = false, $page=1, $limit = LIMIT_PER_PAGE){
        $cond_str = '';
        $cond_params = [];
        
        if(!empty($code)){
            $cond_str .= "WHERE c.`code` LIKE '%".$code."%' OR c.`serial_no` LIKE '%".$code."%'";
            //$cond_params[] = $code;
        }
        
        if($is_total){
            $fields = "COUNT(1) AS TOTAL";
            $order_limit_str = "";
        } else{
            $fields = "
                  c.`code`
				, c.`serial_no`
                , c.`amount`
                , CASE c.`status_id` 
                    WHEN 5 THEN 'Available' 
                    WHEN 6 THEN 'Used' 
                    ELSE '?' 
                  END AS `status`
                , s.`username` AS used_by
                , p.`created_at` AS `used_at`";
            
            $order_limit_str = " ORDER BY c.`status_id` DESC, c.`code` ASC
            LIMIT ".($page-1)*$limit.", {$limit}";
        }
        
        $sql = "SELECT ".$fields."
            FROM `scratch_cards` c
            LEFT JOIN `payments` p ON p.`id_payment_key` = c.`ref_id` AND p.`type` = 'Scratch Card'
            LEFT JOIN `subscribers` s ON s.`id_subscriber_key` = p.`subscriber_id`
            ".$cond_str.$order_limit_str;
        
        return $data = DB::getInstance()->query($sql, $cond_params)->results();
    }
}
