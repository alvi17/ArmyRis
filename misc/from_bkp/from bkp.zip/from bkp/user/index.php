<?php

/**
 * Description of User List
 *
 * @author Md. Rafiqul Islam <rafiq.kuet@gmail.com>
 * @date October 22, 2016 22:57
 */

require "../core/config.php";
require "../core/init.php";
require "../modules/user/User.php";

$pageCode       = 'user-index';
$pageContent	= 'user/index';
$pageTitle 		= 'List Users';

if(!Auth::isAuthenticatedPage($pageCode)){
    Session::put('error', "You do not have permission to access '{$pageTitle}' page.");
    Utility::redirect(BASE_URL.'/login.php');
}


$user = new User();
$db = DB::connectDb();

// $user->listUsers();


$sql = "SELECT
         u.`id`
       , u.`username`
       , TRIM(CONCAT_WS(' ', u.`firstname`, u.`lastname`)) AS fullname
       , rnk.`name` AS rank
       , u.`mobile`
       FROM `users` u
       LEFT JOIN `ranks` rnk ON rnk.`id` = u.`rank`";

$query = $db->prepare($sql);
$query->execute();
$data = $query->fetchAll();
$count = $query->rowCount();

foreach($data as $key=>$val){
    $data[$key]['roles'] = $user->getUserRolesAsString($val['id']);
}


require BASE_DIRECTORY.'/views/layouts/admin-base.phtml';